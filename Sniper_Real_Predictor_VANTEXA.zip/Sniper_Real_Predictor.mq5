//+------------------------------------------------------------------+
//|                   Sniper Real Predictor - VANTEXA                |
//|                 EURUSD M1 Manual Signal Indicator                |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"
#property indicator_chart_window
#property indicator_plots   2
#property indicator_buffers 2
#property indicator_label1  "BUY"
#property indicator_type1   DRAW_ARROW
#property indicator_color1  clrLime
#property indicator_width1  2
#property indicator_label2  "SELL"
#property indicator_type2   DRAW_ARROW
#property indicator_color2  clrRed
#property indicator_width2  2

input group "=== Sniper Real Predictor ==="
input int      InpEMAFast          = 5;
input int      InpEMASlow          = 8;
input int      InpRSIPeriod        = 10;
input int      InpADXPeriod        = 14;
input int      InpATRPeriod        = 14;
input double   InpADXMin           = 20.0;
input double   InpMinATR           = 0.00010;
input bool     InpOnlyEURUSD       = true;
input bool     InpOnlyM1           = true;
input int      InpMinBarsBetween   = 3;

input group "=== Alerts ==="
input bool     InpPopupAlert       = true;
input bool     InpPushNotification = true;
input bool     InpSoundAlert       = true;
input string   InpSoundFile        = "alert.wav";

double BuyBuffer[];
double SellBuffer[];
int hFast = INVALID_HANDLE;
int hSlow = INVALID_HANDLE;
int hRSI  = INVALID_HANDLE;
int hADX  = INVALID_HANDLE;
int hATR  = INVALID_HANDLE;
datetime lastProcessedBar = 0;
int lastSignalShift = -100000;

int OnInit()
{
   SetIndexBuffer(0, BuyBuffer, INDICATOR_DATA);
   SetIndexBuffer(1, SellBuffer, INDICATOR_DATA);
   ArraySetAsSeries(BuyBuffer, true);
   ArraySetAsSeries(SellBuffer, true);
   PlotIndexSetInteger(0, PLOT_ARROW, 233);
   PlotIndexSetInteger(1, PLOT_ARROW, 234);
   PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(1, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   hFast = iMA(_Symbol, PERIOD_CURRENT, InpEMAFast, 0, MODE_EMA, PRICE_CLOSE);
   hSlow = iMA(_Symbol, PERIOD_CURRENT, InpEMASlow, 0, MODE_EMA, PRICE_CLOSE);
   hRSI  = iRSI(_Symbol, PERIOD_CURRENT, InpRSIPeriod, PRICE_CLOSE);
   hADX  = iADX(_Symbol, PERIOD_CURRENT, InpADXPeriod);
   hATR  = iATR(_Symbol, PERIOD_CURRENT, InpATRPeriod);
   if(hFast == INVALID_HANDLE || hSlow == INVALID_HANDLE || hRSI == INVALID_HANDLE || hADX == INVALID_HANDLE || hATR == INVALID_HANDLE)
      return INIT_FAILED;
   IndicatorSetString(INDICATOR_SHORTNAME, "Sniper Real Predictor");
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   if(hFast != INVALID_HANDLE) IndicatorRelease(hFast);
   if(hSlow != INVALID_HANDLE) IndicatorRelease(hSlow);
   if(hRSI  != INVALID_HANDLE) IndicatorRelease(hRSI);
   if(hADX  != INVALID_HANDLE) IndicatorRelease(hADX);
   if(hATR  != INVALID_HANDLE) IndicatorRelease(hATR);
}

bool AllowedChart()
{
   if(InpOnlyEURUSD && StringFind(_Symbol, "EURUSD") < 0) return false;
   if(InpOnlyM1 && _Period != PERIOD_M1) return false;
   return true;
}

void NotifySignal(bool buy, datetime barTime, double adx)
{
   if(barTime == lastProcessedBar) return;
   lastProcessedBar = barTime;
   string side = buy ? "BUY" : "SELL";
   string msg = _Symbol + " | " + side + " | M1 | Enter next candle | ADX " + DoubleToString(adx, 1);
   if(InpPopupAlert) Alert(msg);
   if(InpSoundAlert) PlaySound(InpSoundFile);
   if(InpPushNotification) SendNotification(msg);
}

int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   if(!AllowedChart()) return rates_total;
   int minimum = MathMax(InpEMASlow, MathMax(InpRSIPeriod, MathMax(InpADXPeriod, InpATRPeriod))) + 20;
   if(rates_total < minimum) return 0;
   ArraySetAsSeries(time, true);
   ArraySetAsSeries(open, true);
   ArraySetAsSeries(high, true);
   ArraySetAsSeries(low, true);
   ArraySetAsSeries(close, true);

   double fast[], slow[], rsi[], adx[], plusDI[], minusDI[], atr[];
   ArraySetAsSeries(fast, true); ArraySetAsSeries(slow, true); ArraySetAsSeries(rsi, true);
   ArraySetAsSeries(adx, true); ArraySetAsSeries(plusDI, true); ArraySetAsSeries(minusDI, true); ArraySetAsSeries(atr, true);

   int need = rates_total;
   if(CopyBuffer(hFast,0,0,need,fast)<=0) return prev_calculated;
   if(CopyBuffer(hSlow,0,0,need,slow)<=0) return prev_calculated;
   if(CopyBuffer(hRSI,0,0,need,rsi)<=0) return prev_calculated;
   if(CopyBuffer(hADX,0,0,need,adx)<=0) return prev_calculated;
   if(CopyBuffer(hADX,1,0,need,plusDI)<=0) return prev_calculated;
   if(CopyBuffer(hADX,2,0,need,minusDI)<=0) return prev_calculated;
   if(CopyBuffer(hATR,0,0,need,atr)<=0) return prev_calculated;

   int start = (prev_calculated==0) ? rates_total-minimum : MathMin(rates_total-prev_calculated+3, rates_total-minimum);
   if(start < 1) start = 1;

   for(int i=start; i>=1; i--)
   {
      BuyBuffer[i]=EMPTY_VALUE;
      SellBuffer[i]=EMPTY_VALUE;
      if(atr[i] < InpMinATR) continue;

      bool buySignal = fast[i] > slow[i] && rsi[i] > 50.0 && adx[i] >= InpADXMin && plusDI[i] > minusDI[i] && close[i] > open[i];
      bool sellSignal = fast[i] < slow[i] && rsi[i] < 50.0 && adx[i] >= InpADXMin && minusDI[i] > plusDI[i] && close[i] < open[i];

      if(lastSignalShift > 0 && MathAbs(lastSignalShift - i) < InpMinBarsBetween)
      {
         buySignal=false;
         sellSignal=false;
      }

      if(buySignal)
      {
         BuyBuffer[i]=low[i]-atr[i]*0.25;
         lastSignalShift=i;
      }
      else if(sellSignal)
      {
         SellBuffer[i]=high[i]+atr[i]*0.25;
         lastSignalShift=i;
      }
   }

   int i=1;
   if(atr[i] >= InpMinATR)
   {
      bool buySignal = fast[i] > slow[i] && rsi[i] > 50.0 && adx[i] >= InpADXMin && plusDI[i] > minusDI[i] && close[i] > open[i];
      bool sellSignal = fast[i] < slow[i] && rsi[i] < 50.0 && adx[i] >= InpADXMin && minusDI[i] > plusDI[i] && close[i] < open[i];
      if(buySignal) NotifySignal(true,time[i],adx[i]);
      else if(sellSignal) NotifySignal(false,time[i],adx[i]);
   }

   return rates_total;
}
//+------------------------------------------------------------------+
